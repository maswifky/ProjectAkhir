package com.example.llogin;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class CallCenterActivty extends AppCompatActivity {

    String phone;
    private Button call;
    private TextView number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call_center_activty);

        call = findViewById(R.id.button);
        number = findViewById(R.id.number);
        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String number = "081390941558";
                Intent call = new Intent(Intent. ACTION_DIAL);
                call.setData(Uri. fromParts("tel",number,null));
                startActivity(call);
            }
        });

    }
}
