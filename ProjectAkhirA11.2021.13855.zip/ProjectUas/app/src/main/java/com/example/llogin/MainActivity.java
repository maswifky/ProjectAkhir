package com.example.llogin;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class MainActivity extends AppCompatActivity {
    private CardView btn1, btn2, btn3, btn4, btn5, btn6;
    private Button total;
    private int totalharga,totaltiket=0;
    private TextView harga;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
        btn5 = findViewById(R.id.btn5);
        btn6 = findViewById(R.id.btn6);
        total= (Button)findViewById(R.id.totalid);
        harga = findViewById(R.id.harga);


        Intent terima = getIntent();
        int terimaTotal = terima.getIntExtra("total", 0);
        int terimaHarga = terima.getIntExtra("harga",0);


        total.setText("Total : "+Integer.toString(terimaTotal));
        harga.setText("Harga : "+"Rp"+Integer.toString(terimaHarga)+",00");


        btn1.setOnClickListener(view -> {
            int updateTotal = terima.getIntExtra("total",0);
            int updateHarga = terima.getIntExtra("harga",0);
            Intent update = new Intent(MainActivity.this, Deskripsi1Activity.class);
            update.putExtra("update", updateTotal);
            update.putExtra("update2",updateHarga);
            startActivity(update);
        });

        btn2.setOnClickListener(view -> {
            int updateTotal = terima.getIntExtra("total",0);
            int updateHarga = terima.getIntExtra("harga",0);
            Intent update = new Intent(MainActivity.this, Deskripsi2Activity.class);
            update.putExtra("update", updateTotal);
            update.putExtra("update2",updateHarga);
            startActivity(update);
        });

        btn3.setOnClickListener(view -> {
            int updateTotal = terima.getIntExtra("total",0);
            int updateHarga = terima.getIntExtra("harga",0);
            Intent update = new Intent(MainActivity.this, Deskripsi3Activity.class);
            update.putExtra("update", updateTotal);
            update.putExtra("update2",updateHarga);
            startActivity(update);
        });
        btn4.setOnClickListener(view -> {
            int updateTotal = terima.getIntExtra("total",0);
            int updateHarga = terima.getIntExtra("harga",0);
            Intent update = new Intent(MainActivity.this, Deskripsi4Activity.class);
            update.putExtra("update", updateTotal);
            update.putExtra("update2",updateHarga);
            startActivity(update);
        });

        btn5.setOnClickListener(view -> {
            int updateTotal = terima.getIntExtra("total",0);
            int updateHarga = terima.getIntExtra("harga",0);
            Intent update = new Intent(MainActivity.this, Deskripsi5Activity.class);
            update.putExtra("update", updateTotal);
            update.putExtra("update2",updateHarga);
            startActivity(update);
        });

        btn6.setOnClickListener(view -> {
            int updateTotal = terima.getIntExtra("total",0);
            int updateHarga = terima.getIntExtra("harga",0);
            Intent update = new Intent(MainActivity.this, Deskripsi6Activity.class);
            update.putExtra("update", updateTotal);
            update.putExtra("update2",updateHarga);
            startActivity(update);
        });

        total.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent UploadBayar = new Intent(MainActivity.this, PembayaranActivity.class);
                startActivity(UploadBayar);
            }
        });



    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_call:
                Intent callScreen = new Intent(MainActivity.this,
                        CallCenterActivty.class);
                startActivity(callScreen);
                return true;
            case R.id.action_sms:
                Intent smsScreen = new Intent(MainActivity.this,
                        SmsActivity.class);
                startActivity(smsScreen);
                return true;
            case R.id.action_maps:
                Intent mapsScreen = new Intent(MainActivity.this,
                        MapsActivity.class);
                startActivity(mapsScreen);
                return true;
            case R.id.action_update:
                Intent updateScreen = new Intent(MainActivity.this,
                        UpdateUser.class);
                startActivity(updateScreen);
                return true;
            /*case R.id.bayar:
                Intent UploadBayar = new Intent(DashboardActivity.this, UploadBuktiActivity.class);
                startActivity(UploadBayar);
                return true;*/
            case R.id.action_logout:
                Intent LogOut = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(LogOut);
                return true;
            default:
        }
        return super.onOptionsItemSelected(item);
    }
    public void displayToast(String message) {
        Toast.makeText(getApplicationContext(), message,
                Toast.LENGTH_SHORT).show();
    }

    public void Total(View view) {
    }
}


